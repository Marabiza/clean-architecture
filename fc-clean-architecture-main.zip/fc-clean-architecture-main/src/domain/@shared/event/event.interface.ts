export default interface EventInterface {
  dataTimeOccurred: Date;
  eventData: any;
}
